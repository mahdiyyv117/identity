from setuptools import setup

setup(name='identity', version='1.0',
      py_modules=['identity'],
      author_email='iranpro117@gmail.com')
